#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>
#include "stdlib.h"

#define MAX_LEN 512
#define MAX_PathLEN 312
char Input[512];
int words;
int countW;
int size;


//This method reads from the input how many words the user typed and counts them
// in order to dynamic allocate a new * char which equals to the numbers of the words + 1
void Words(char *str, int *wordCount) {
    int wordC = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[0] == ' ') {
            break;
        }
        if ((str[i] == ' ' && str[i + 1] != ' ') || str[i + 1] == '\0') {
            wordC++;
        }
    }
    *wordCount = wordC;
}

int main() {
    words = 0;
    int NumOfCommands = 0;
    int NumOfWords = 0;

    while (1) {
        words = 0;
        char path[MAX_PathLEN];
        getcwd(path, MAX_PathLEN);
        strcat(path, ">");
        printf("%s", path);
        fgets(Input, MAX_LEN, stdin);
        NumOfCommands++;
        fflush(stdin);
        Input[strlen(Input) - 1] = '\0';
        Words(Input, &words);
        NumOfWords += words;

        //if the input is either a space or none then the method doesn't count them as a command.
        if (strlen(Input) <= 0 || (strcmp(Input, " ") == 0)) {
            NumOfCommands--;

        }
        //if the command entered is cd the system prints a message to the screen
        if (strcmp(Input, "cd") == 0) {

            printf("Command not supported (Yet)\n");


            //if the command entered is done then the system prints the number of commands and words through this run.
        } else if (strcmp(Input, "done") == 0) {
            NumOfWords--;
            printf("Total number of commands: %d\n", NumOfCommands);
            printf("Total number of words: %d\n", NumOfWords);
            return 0;


            //In the else case we start by cutting the chars, word by word, and saving them piece by piece
            // and dynamic allocate (calloc) every single word inserted from the user
            // so that we don’t get any junk or any extra space in the system
            // that we don’t need in the memory and can cause memory leaking or any error
        } else {
            int start = 0;
            countW = 0;
            char *com[words + 1];
            com[words] = NULL;
            for (int end = 0; end < strlen(Input); end++) {
                if (Input[end + 1] == ' ' || Input[end + 1] == '\0') {
                    size = end - start + 1;
                    com[countW] = calloc(size, sizeof(char));
                    if (com[countW] == NULL) {
                        fprintf(stderr, "There is a Dynamic Memory Allocation Problem");
                    }
                    strncpy(com[countW], &Input[start], size);
                    countW++;
                    start = end + 2;


                }

            }

            pid_t son;
            son = fork();
            if (son == 0) {
                execvp(com[0], com);
                exit(1);
            }
            wait(NULL);
            for (int i = 0; i < words; i++) {
                free(com[i]);
            }
        }

    }

}
