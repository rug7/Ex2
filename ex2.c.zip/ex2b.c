#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>
#include "stdlib.h"

#define MAX_LEN 512
#define MAX_PathLEN 312
char HistoryList[] = "History";
char ca;
char Input[512];
char NewInput[512];
int words, words1;
int countW;
int size;

//This method reads from the input how many words the user typed and counts them
// in order to dynamic allocate a new * char which equals to the numbers of the words + 1
void Words(char *str, int *wordCount) {
    int wordC = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[0] == ' ') {
            break;
        }
        if ((str[i] == ' ' && str[i + 1] != ' ') || str[i + 1] == '\0') {
            wordC++;
        }
    }
    *wordCount = wordC;
}

//This method counts the lines in the file by opening the file and only read it and count
// so that we know where the file ends.
void lines(char *FileName, char *Line) {
    FILE *f;
    char ch;
    int LineCount = 0;
    f = fopen(FileName, "r");


    //getc gets the next char in a line so the first ch= getc(f) means that ch is the first char in the file
    //and if ch doesn't equal the end of the file then ch equals the next char in the line,
    //if ch equals to "\n" then there is a new line and the count is up by one.
    for (ch = getc(f); ch != EOF; ch = getc(f)) {
        if (ch == '\n') {
            LineCount++;
        }
    }
    fclose(f);
    *Line = LineCount;

}

//this method prints the input from the user in the History FILE.
//and if there is a space before the command or after or both then the command
//doesn't enter the history list
void PrintInTheHistory() {
    if(Input[0] != ' ' || Input[strlen(Input-1)] != ' '){
        if(strlen(Input) >0){

            FILE *f;
            f = fopen(HistoryList, "a");

            fprintf(f, "%s\n", Input);
            fclose(f);
        }
    }
}

//This method detects an '!' At the start of the command and then
// removes the explanation mark from the char and returns the char without the '!'
void RemoveEXPL(char *s) {
    int len = strlen(s);
    for (int i = 0; i < len; i++) {
        if (s[i] == '!') {
            for (int j = i; j < len; j++) {
                s[j] = s[j + 1];
            }
            len--;
            i--;
        }
    }

}

int main() {
    words = 0;//to count the words in any case besides the '!' case.
    words1 = 0;//to count the words after detecting '!'.
    char lineNum = 0;
    int NumOfCommands = 0;
    int NumOfWords = 0;

    while (1) {
        words = 0;
        words1 = 0;
        lineNum = 0;
        char path[MAX_PathLEN];
        getcwd(path, MAX_PathLEN);
        strcat(path, ">");
        printf("%s", path);
        fgets(Input, MAX_LEN, stdin);
        NumOfCommands++;
        fflush(stdin);
        Input[strlen(Input) - 1] = '\0';
        Words(Input, &words);
        NumOfWords += words;

        //if the input is either a space or none then the method doesn't count them as a command.
        if (strlen(Input) <= 0 || (strcmp(Input, " ") == 0)) {
            NumOfCommands--;

        }
        //if the command entered is cd the system prints a message to the screen
        if (strcmp(Input, "cd") == 0) {

            printf("Command not supported (Yet)\n");


            //if the command entered is done then the system prints the number of commands and words through this run.
        } else if (strcmp(Input, "done") == 0) {
            NumOfWords--;
            printf("Total number of commands: %d\n", NumOfCommands);
            printf("Total number of words: %d\n", NumOfWords);
            return 0;



            //in this case if the Input equals is the word history and only history by itself the program
            //opens a file for reading and writing and writes in it all the past inputs from the user
            //and after the writing is over it prints the data on the screen.
        } else if (strcmp(Input, "history") == 0) {
            FILE *f;
            f = fopen(HistoryList, "a");
            fprintf(f, "%s\n", "history");
            fclose(f);

            f = fopen(HistoryList, "a+");
            ca = fgetc(f);

            while (ca != EOF) {
                if ((strcpy(Input, " ") == 0) || (strcpy(Input, "cd") == 0) || (strcpy(Input, "done") == 0)) {
                    break;
                }
                printf("%c", ca);
                ca = fgetc(f);
            }

            fclose(f);


            //In this case we start by copying the input to a new char and sending the
            //new char to the RemoveEXPL method to remove the '!' from the start and then
            //using stoi method to convert the char into an integer, then comparing the integer
            //with the total number of lines in the history file, if the integer is within the
            //range then the system prints the command found in the selected line
            //and then sends the command to the rest of the code then it makes the command run
            //then it starts cutting the command and dynamic allocate every single word in the
            //command then sending it to the execpv for it to work (if the command is legal)

        } else if (Input[0] == '!') {
            strcpy(NewInput, Input);
            RemoveEXPL(NewInput);
            int comNum = atoi(NewInput);
            lines(HistoryList, &lineNum);

            if ((NewInput <= &lineNum)) {
                FILE *f;
                f = fopen(HistoryList, "a+");
                for (int i = 0; i < comNum; i++) {
                    fgets(NewInput, MAX_LEN, f);
                }
                fprintf(f, "%s", NewInput);
                fclose(f);

                Words(NewInput, &words1);

                if (NewInput[strlen(NewInput) - 1] == '\n') {
                    NewInput[strlen(NewInput) - 1] = '\0';
                }
                printf("%s\n", NewInput);


                int start = 0;
                countW = 0;
                char *com[words1 + 1];
                com[words1] = NULL;
                for (int end = 0; end < strlen(NewInput); end++) {
                    if (NewInput[end + 1] == ' ' || NewInput[end + 1] == '\0') {
                        size = end - start + 1;
                        com[countW] = calloc(size, sizeof(char));
                        if (com[countW] == NULL) {
                            fprintf(stderr, "There is a Dynamic Memory Allocation Problem");
                        }
                        strncpy(com[countW], (NewInput + start), size);
                        countW++;
                        start = end + 2;


                    }

                }
                pid_t child;
                child = fork();
                if (child == 0) {
                    execvp(com[0], com);
                    exit(1);
                }
                wait(NULL);
                for (int i = 0; i < words; i++) {
                    free(com[i]);
                }

            }



            //In the else case we start by cutting the chars, word by word, and saving them piece by piece
            // and dynamic allocate (calloc) every single word inserted from the user
            // so that we don’t get any junk or any extra space in the system
            // that we don’t need in the memory and can cause memory leaking or any error
        } else {
            int start = 0;
            countW = 0;
            char *com[words + 1];
            com[words] = NULL;
            for (int end = 0; end < strlen(Input); end++) {
                if (Input[end + 1] == ' ' || Input[end + 1] == '\0') {
                    size = end - start + 1;
                    com[countW] = calloc(size, sizeof(char));
                    if (com[countW] == NULL) {
                        fprintf(stderr, "There is a Dynamic Memory Allocation Problem");
                    }
                    strncpy(com[countW], &Input[start], size);
                    countW++;
                    start = end + 2;


                }

            }
            PrintInTheHistory();

            //using fork and execpv to make the input run as a command
            pid_t son;
            son = fork();
            if (son == 0) {
                execvp(com[0], com);
                exit(1);
            }
            wait(NULL);
            for (int i = 0; i < words; i++) {
                free(com[i]);
            }
        }

    }

}